#!/bin/sh
set -eux

if [ "$1" != 0 ]; then
    exit 1
fi
