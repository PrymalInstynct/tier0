# `setup_vault_server_cert`
Generates and key and self-signed certificate for the Vault server.

## Notes
* Requires the [`community.crypto` collection](https://galaxy.ansible.com/community/crypto).
