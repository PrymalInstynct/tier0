# `setup_vault_configure_engine_pki`
Performs configuration of the PKI engine in Vault.
