.. _docsite_root_index:

Ansible collection documentation preview
========================================

This docsite contains documentation from ``community.hashi_vault``.


.. toctree::
   :maxdepth: 2
   :caption: Collections:

   collections/index


.. toctree::
   :maxdepth: 1
   :caption: Plugin indexes:
   :glob:

   collections/index_*
